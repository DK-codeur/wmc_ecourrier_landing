
$(document).ready(function() {

    /* ==============================================
    Magnific Popup
    =============================================== */
        $('.popup-video').magnificPopup({
          disableOn: 700,
          type: 'iframe',
          mainClass: 'mfp-fade',
          removalDelay: 160,
          preloader: false,
          fixedContentPos: false
        });

    });