
$(document).ready(function() {


    /* ==============================================
    carousel
    =============================================== */
        $('#testi-carousel').owlCarousel({
            items: 1,
            loop:false,
            margin:24,
            nav:false,
            responsive:{
                576:{
                    items:2
                },
    
            }
        });
    });